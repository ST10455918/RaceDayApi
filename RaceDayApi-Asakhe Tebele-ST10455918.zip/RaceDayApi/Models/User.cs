﻿namespace RaceDayApi.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; } = "";
        public string Email { get; set; } = "";
        public string PasswordHash { get; set; } = "";
        public string Role { get; set; } = "Participant";

        public string? ProfileImageUrl { get; set; }
        public string? BannerImageUrl { get; set; }
    }
}